import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";

import itemRoute from "./route/item.route.js";
import userRoute from "./route/user.route.js";

const app = express();
app.use(express.json());
app.use(cors());

dotenv.config();

const PORT = process.env.PORT || 4000;
const URI = process.env.MongoDBURI;

// Connect to MongoDB
mongoose.connect(URI, {
  //useNewUrlParser: true,
  //useUnifiedTopology: true,
}).then(() => {
  console.log("Connected to MongoDB");
}).catch((error) => {
  console.log("Error connecting to MongoDB:", error);
});

// Define routes
app.use("/item", itemRoute);
app.use("/user", userRoute);

app.listen(PORT, () => {
  console.log(`Example app listening on port ${PORT}`);
});